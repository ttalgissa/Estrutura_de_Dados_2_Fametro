# Respostas – Questões Teóricas (Ponteiros em C)

1. **Resposta:** b) Um ponteiro armazena o endereço de memória de uma variável.  
2. **Resposta:** d) Acessa (dereferencia) o valor armazenado no endereço de memória para o qual o ponteiro aponta.  
3. **Resposta:** c) Para alocar um bloco de memória de um tamanho especificado em bytes e retornar um ponteiro para o início desse bloco.  
4. **Resposta:** `modifica(&num, num);`  
